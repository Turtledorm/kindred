PyJ2D - Python-to-Java Multimedia Framework

PyJ2D module was modelled on Pygame commands that permits scripts coded in Python/Pygame to run in the Java virtual machine (JVM) using the Jython interpreter. This permits the deployment of JVM applications without extensive editing of the script. The current version of the module supports a subset of Pygame functionality. Information concerning use of the PyJ2D module is included in guide.txt.

PyJ2D is released under the MIT License, see LICENSE.txt for further information.

PyJ2D page: http://gatc.ca/projects/pyj2d/
PyJ2D docs: http://gatc.ca/projects/pyj2d/doc/

