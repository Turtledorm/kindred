#PyJ2D - Copyright (C) 2011 James Garnon <http://gatc.ca/>
#Released under the MIT License <http://opensource.org/licenses/MIT>

"""
JApplet/JFrame objects.
"""

japplet = None

jframe = None

